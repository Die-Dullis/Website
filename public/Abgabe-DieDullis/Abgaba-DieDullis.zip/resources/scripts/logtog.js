function toggle() {
    document.querySelector('.login-container').classList.toggle('off');
    document.querySelector('.register-container').classList.toggle('off');
}
